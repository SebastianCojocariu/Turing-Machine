#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 10001

//functie care verifica daca am ajuns cu stare_curenta intr-o stare finala(1),altfel(0)
int verifica(char **stari_finale,int nr_stari_finale,char *stare_curenta)
{
    int k=0;
    for(;k<nr_stari_finale;k++)
        if(strcmp(stari_finale[k],stare_curenta)==0)
        return 1;
    return 0;
}


int main()
{
    FILE *in=fopen("task1.in","r");
    FILE *out=fopen("task1.out","wr");
    //stari_conditii : matrice in care stocam tranzitiile(stari_conditii[2*k]->stari_conditii[2*k+1],pt k=0,(*nr_tranzitii)-1)
    char **stari_conditii;
    //stari_finale : matrice in care stocam starile finale ale MT
    char **stari_finale;
    //caractere_citite: matrice pt caracterele citite pe cele 2 benzi cu corespondenta (caracter_citit[2*k] pt banda1,caracter_citit[2*k+1] pt banda2,pt k=0,(*nr_tranzitii)-1))
    char **caracter_citit;
    //caracter_schimbat:matrice pt caracterele schimbate pe cele 2 benzi cu corespondenta (caracter_schimbat[2*k] pt banda1,caracter_schimbat[2*k+1] pt banda2,pt k=0,(*nr_tranzitii)-1)
    char **caracter_schimbat;
    //destinatie:matrice care stocheaza cum se misca MT pe banda(adica L,H,R) cu corespondenta destinatie[2*k] pt banda1,respectiv destinatie[2*k+1] pt banda 2,pt k=0,(*nr_tranzitii)-1))
    char **destinatie;
    //nr_stari_finale
    int *nr_stari_finale=(int*)malloc(sizeof(int));
    //nr_tranzitii
    int *nr_tranzitii=(int*)malloc(sizeof(int));
   // cele 2 benzi pe care se deplaseaza MT
    char *banda1,*banda2,*stare_initiala;
    int nr_stari,i=0,j=0;
    char *stare=malloc(101);
    
    fscanf(in,"%d",&nr_stari);
    //citim starile din fisier
    for(;i<nr_stari;i++)
        fscanf(in,"%s",stare);
    //citim nr_stari_finale
    fscanf(in,"%d",nr_stari_finale);
   
    stari_finale=(char**)malloc((*nr_stari_finale)*sizeof(char*));
    //citim si stocam starile finale in stari_finale.
    for(i=0;i<*nr_stari_finale;i++)
    {
        stari_finale[i]=malloc(101);
        fscanf(in,"%s",stari_finale[i]);
        printf("%s",stari_finale[i]);

    }
    stare_initiala=(char*)malloc(101*sizeof(char));
    //citim starea initiala si o stocam in stare_initiala
    fscanf(in,"%s",stare_initiala);
    //citim nr de tranzitii si stocam in nr_tranzitii
    fscanf(in,"%d",nr_tranzitii);
    //alocam memorie
    stari_conditii=(char**)malloc(2*(*nr_tranzitii)*sizeof(char*));
    destinatie=(char**)malloc((2*(*nr_tranzitii))*sizeof(char*));
    caracter_schimbat=(char**)malloc((2*(*nr_tranzitii))*sizeof(char*));
    caracter_citit=(char**)malloc((2*(*nr_tranzitii))*sizeof(char*));
    //introducem tranzitiile,caracterele citite,caracterele schimbate si destinatia,cu corespondenta ca pt 2*k,2*k+1 se stocheaza mereu informatiile de pe linia a-k+1 a din punctul in care s-a citit nr_tranzitii din fisier,(pt 2*k->banda1 iar pt 2*k+1->banda2)
    for(i=0;i<(*nr_tranzitii);i++)
    {
        stari_conditii[2*i]=(char*)malloc(101*sizeof(char));
        stari_conditii[2*i+1]=(char*)malloc(101*sizeof(char));
        caracter_citit[2*i]=(char*)malloc(3*sizeof(char));
        caracter_citit[2*i+1]=(char*)malloc(3*sizeof(char));
        caracter_schimbat[2*i]=(char*)malloc(3*sizeof(char));
        caracter_schimbat[2*i+1]=(char*)malloc(3*sizeof(char));
        destinatie[2*i]=(char*)malloc(3*sizeof(char));
        destinatie[2*i+1]=(char*)malloc(3*sizeof(char));

        fscanf(in,"%s",stari_conditii[2*i]);
        printf("%s ",stari_conditii[2*i]);
        fscanf(in,"%s",caracter_citit[2*i]);
        printf("%s ",caracter_citit[2*i]);

        fscanf(in,"%s",caracter_citit[2*i+1]);
        printf("%s ",caracter_citit[2*i+1]);
        fscanf(in,"%s",stari_conditii[2*i+1]);
        printf("%s ",stari_conditii[2*i+1]);

        fscanf(in,"%s",caracter_schimbat[2*i]);
           printf("%s ",caracter_schimbat[2*i]);

        fscanf(in,"%s",destinatie[2*i]);
        printf("%s ",destinatie[2*i]);
        fscanf(in,"%s",caracter_schimbat[2*i+1]);
        printf("%s ",caracter_schimbat[2*i+1]);
        fscanf(in,"%s",destinatie[2*i+1]);
        printf("%s \n",destinatie[2*i+1]);
    }

    //citim benzile in banda1,respectiv banda2 din fisier
    banda1=(char*)malloc(MAX*sizeof(char));
    banda2=(char*)malloc(MAX*sizeof(char));
    fscanf(in,"%s",banda1);
    fscanf(in,"%s",banda2);

    //copiem stare_initiala in stare_curenta;
    char *stare_curenta=malloc(101);
    strcpy(stare_curenta,stare_initiala);


    i=1,j=1;
    //pt a intra in while,cu mentiunea ca ok va fi 1 in interiorul while-ului cand se poate face o tranzitie din starea curenta,respectiv 0 invers(moment in care se va iesi din while si se va afisa mesajul de eroare corespunzator)
    int ok=1;

    //intram intr-un while care se va executa atata timp cat nu suntem in stare finala(cu stare_curenta) si putem executa o tranzitie din stare curenta(adica daca se potriveste stare_curenta,caracter citit pe prima banda si caracter citit pe a 2a banda cu informatiile corespunzatoare de pe una din liniile de tranzitii din fisier)
    while(verifica(stari_finale,*nr_stari_finale,stare_curenta)==0&&ok==1)
    {
        int k=0;
        ok=0;
        for(;k<*nr_tranzitii;k++)
        {
            if(strcmp(stari_conditii[2*k],stare_curenta)==0&&
               caracter_citit[2*k][0]==banda1[i]&&caracter_citit[2*k+1][0]==banda2[j])
            {
                ok=1;

                banda1[i]=caracter_schimbat[2*k][0];
                banda2[j]=caracter_schimbat[2*k+1][0];
                if(destinatie[2*k][0]=='R')
                i++;
                if(destinatie[2*k][0]=='L')
                i--;

                if(destinatie[2*k+1][0]=='R')
                j++;
                if(destinatie[2*k+1][0]=='L')
                j--;
                strcpy(stare_curenta,stari_conditii[2*k+1]);

                 if(i==strlen(banda1))
             {      banda1[i]='#';
                    banda1[i+1]='\0';
             }
                if(j==strlen(banda2))
             {      banda2[j]='#';
                    banda2[j+1]='\0';
             }

                break;


            }

        }

    }

    //daca ok==1 inseamna ca MT s-a terminat,deci afisam benzile;
    if(ok==1)
   {
    fprintf(out,"%s\n",banda1);

    printf("%s \n",banda1);
    fprintf(out,"%s\n",banda2);
    printf("%s \n",banda2);
   }
   //daca ok==0 inseamna ca ne-am blocat intr-o stare si nu putem face o tranzitie,deci afisam mesajul de eroare
   else
    fprintf(out,"The machine has blocked!\n");

    return 0;

    }
